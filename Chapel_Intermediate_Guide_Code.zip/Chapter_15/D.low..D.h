iter windows3(A: [] real) {
const D = A.domain; for i in D.low..D.high-2 do yield (A[i],A[i+1],A[i+2]);
}
