use IO, core;
iter scoreLines(path: string) {
var f = open(path, iomode.r), r = f.reader(); defer { r.close(); f.close(); }
var name, line: string;
while r.readln(name) && r.readln(line) do yield (name, line);
}
