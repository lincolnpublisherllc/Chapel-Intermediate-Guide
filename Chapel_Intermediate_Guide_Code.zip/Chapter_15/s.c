use core, fmt;
proc test_parse_ok() {
const (ok, s) = parseScores("88 93 79");
assert(ok && s.a == 88 && s.b == 93 && s.c == 79);
}
proc test_report() {
const s = new Scores(88, 93, 79);
const out = report("Ada", s);
assert(out.find("Student: Ada") >= 0);
assert(out.find("Grade: B") >= 0);
}
proc main() {
test_parse_ok();
test_report();
writeln("fmt ok");
}
