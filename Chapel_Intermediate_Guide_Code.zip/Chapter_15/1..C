const Rows = 1..R, Cols = 1..C;
const MDom = {Rows, Cols};
var M: [MDom] real;
forall (r, c) in MDom do M[r, c] = r + c;
