module logkit {
use stats;
use formats.csv;

config const input: string = "";
config const limit: int = 0;
config const verbose: bool = false;

proc main() {
if input == "" {
writeln("Usage: logkit --input=<file> [--limit=N] [--verbose=true]");
return;
}
const lines = readAll(input, limit);
if verbose then writeln("[debug] read ", lines.domain.size, " lines");
const s = stats.summarize(lines);
writeln(renderSummary(s));
}
}
