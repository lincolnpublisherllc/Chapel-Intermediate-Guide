Idempotency: include export_id in payload and as a header; the service should de-dup.
Backpressure: if the service replies 429/503, honor Retry-After when available; cap retries.
