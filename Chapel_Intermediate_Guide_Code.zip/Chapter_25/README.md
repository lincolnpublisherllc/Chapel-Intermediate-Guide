require "src/c/http_post.c", "src/c/http_post.h";

extern proc http_post_json(url: c_string, body: c_string, timeout_sec: c_long): c_int;

proc postJSON(url: string, body: string, timeoutSec: int = 15): (bool, int) {
const rc = http_post_json(url.c_str(), body.c_str(), timeoutSec:c_long):int;
return (rc == 0, rc);
}
