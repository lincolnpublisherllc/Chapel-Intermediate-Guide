int http_post_json(const char* url, const char* body, long timeout_sec) {
CURL *h = curl_easy_init(); if (!h) return 2;
curl_easy_setopt(h, CURLOPT_URL, url);
curl_easy_setopt(h, CURLOPT_POSTFIELDS, body);
curl_easy_setopt(h, CURLOPT_HTTPHEADER, curl_slist_append(NULL, "Content-Type: application/json"));
curl_easy_setopt(h, CURLOPT_TIMEOUT, timeout_sec);
CURLcode rc = curl_easy_perform(h);
long http_code = 0; curl_easy_getinfo(h, CURLINFO_RESPONSE_CODE, &http_code);
curl_easy_cleanup(h);
if (rc != CURLE_OK) return 3;
return (http_code >= 200 && http_code < 300) ? 0 : (int)http_code;
}
