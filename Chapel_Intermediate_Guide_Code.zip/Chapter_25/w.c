module serialize {
use IO;
use metrics;

proc writeCSV(path: string, rows: [] Totals) {
var f = open(path, iomode.cw); var w = f.writer();
w.writeln("endpoint,count,mean_ms");
for r in rows do w.writeln(r.endpoint, ",", r.count, ",", r.meanMs);
w.close(); f.close();
}

proc toJSON(rows: [] Totals, exportId: string): string {
