use util.iterlib;

proc main() {
var c = 0;
for _ in chunks(col0("examples/series.csv"), 2) do c += 1;
assert(c > 0);
writeln("iterlib ok");
}
