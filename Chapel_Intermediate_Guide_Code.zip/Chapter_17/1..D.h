iter windowSums(A: [] int, w: int) where w > 0 {
const D = A.domain;
if D.size < w then yield (0, 0); // or yield nothing; pick a policy

var sum = + reduce [i in D.low..D.low + w - 1] A[i];
yield (D.low, sum);

for i in D.low + 1..D.high - w + 1 {
sum += A[i + w - 1] - A[i - 1];
yield (i, sum);
}
}
