iter col0(path: string) {
var f = open(path, iomode.r), r = f.reader();
defer { r.close(); f.close(); }

var line: string;
while r.readln(line) {
const parts = line.split(",");
if parts.size > 0 {
try {
yield parts[0]:real;
} catch e {
