iter chunks(it: iterable(real), N: int) where N > 0 {
var D = 1..0;
var buf: [D] real;

for x in it {
D = 1..(D.size + 1);
buf[D.high] = x;

if D.size == N {
