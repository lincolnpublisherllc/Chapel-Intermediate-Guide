proc rollingMean(A: [] real, w: int): [] real { … }
