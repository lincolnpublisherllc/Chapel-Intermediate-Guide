proc rolling(A: [] real, w: int): [] real {
writeln("[deprecation] use rollingMean(A, w)");  // for CLI tools; logs are better in libs
return rollingMean(A, w);
}
