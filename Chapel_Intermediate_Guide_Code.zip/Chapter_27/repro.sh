Doc coverageAdd docstrings to all public procs/records. Fail CI if any are missing (simple grep-based check is fine).
