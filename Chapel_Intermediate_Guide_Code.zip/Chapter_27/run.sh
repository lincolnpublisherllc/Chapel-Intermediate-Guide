Lint-ish checks: at least a grep for writeln( in lib modules (avoid stray prints)
