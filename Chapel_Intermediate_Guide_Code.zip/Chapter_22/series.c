The rolling mean here is O(n·w) for clarity. Swap to a prefix-sum approach if w is large: build prefix[i] = + scan A then mean[i] = (prefix[i+w-1]-prefix[i-1])/w.
