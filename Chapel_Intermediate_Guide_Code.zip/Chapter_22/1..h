proc countPositives(A: [] int): int {
return + reduce [x in A] (if x > 0 then 1 else 0);
}

proc histogram8(A: [] int, mask: int): [] int {
const B = 0..7;
var locals: [1..here.maxTaskPar] [B] int;

coforall p in 1..here.maxTaskPar {
for i in p..A.domain.high by here.maxTaskPar {
const bin = (A[i] & mask) % 8;
locals[p][bin] += 1;
}
}
var hist: [B] int;
forall b in B do hist[b] = + reduce [p in 1..here.maxTaskPar] locals[p][b];
return hist;
}
