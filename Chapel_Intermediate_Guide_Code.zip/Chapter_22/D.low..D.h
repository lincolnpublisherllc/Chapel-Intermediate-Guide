const OD = D.low..D.high - window + 1; var R: [OD] real;
meanFixed(A, window, R);
