const N = + reduce [ _ in io.col0(input) ] 1;
const D = 1..N; var A: [D] real;

var i = D.low; for x in io.col0(input) { A[i] = x; i += 1; }

if N < window {
writeln("not enough points: ", N, " < ", window); return;
}
