const cmd = ("./bin/app --input=" + input + " > " + output):c_string;
const rc = system(cmd);
assert(rc == 0, "app failed");
}

proc fileToString(p: string): string {
var f = open(p, iomode.r); var r = f.reader(); var s = ""; var line: string;
while r.readln(line) do s += line + "\n";
r.close(); f.close(); return s;
}

proc main() {
const inP  = "test/golden/small.in";
const gotP = "test/golden/small.out";
const expP = "test/golden/small.out.golden";

runApp(inP, gotP);
const got = fileToString(gotP);
const exp = fileToString(expP);

assert(got == exp, "golden mismatch");
writeln("golden ok");
}
