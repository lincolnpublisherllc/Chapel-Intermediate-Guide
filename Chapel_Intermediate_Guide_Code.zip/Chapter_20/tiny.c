Assertions at module boundaries; no assert on user mistakes.
Fatal only when invariants are broken; recoverable everywhere else.
