module app {
use log, csv, agg;

config const input: string = "";
config const K: int = 3;

proc main() {
if input == "" {
error("missing input"); writeln("Usage: --input=<sales.csv> [--K=3]"); return;
}

info("start", [("file", input)]);

const (A, bad) = agg.fromCSV(input);
if bad > 0 then warn("skipped rows", [("count", bad:string)]);

const top = agg.topKByRevenue(A, K);
