for i in 0..(D.size-1) {
const a = D.low + i;
const b = D.high - i;
if a >= b then break;
const tmp = B[a]; B[a] = B[b]; B[b] = tmp;
}
for i in D do if B[i] != A[i] then return false;
return true;
}

proc main() {
var rng = new randomStream(int, seed=123);
for _ in 1..200 {
const n = (rng.getNext() % 50 + 50):int;   // 50..99
const D = 1..n;
var A: [D] int;
for i in D do A[i] = rng.getNext();
assert(reverseTwiceIsIdentity(A));
}
writeln("property ok");
}
