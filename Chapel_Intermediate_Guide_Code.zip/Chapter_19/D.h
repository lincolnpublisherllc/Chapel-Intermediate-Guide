iter batches(path: string, batchSize: int = 50_000) {
var D = 1..0;
var batch: [D] string;

for ln in lines(path) {
D = 1..(D.size + 1);
batch[D.high] = ln;
if D.size == batchSize {
yield batch;
D = 1..0; // reset
}
}
if D.size > 0 then yield batch;
}
}
