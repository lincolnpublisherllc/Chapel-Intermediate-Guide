proc aggregateCSV(path: string, batchSize: int = 50_000): Accum {
// Collect all batches into a dense array for coforall scheduling
var BD = 1..0; var batches: [BD] [] string;
for b in csv.batches(path, batchSize) {
BD = 1..(BD.size + 1);
batches[BD.high] = b;
}

if BD.size == 0 then return new Accum();

var locals: [BD] Accum;

coforall i in BD do locals[i] = processBatch(batches[i]);
