use IO;

record Point2f { var x: real(32); var y: real(32); }

proc savePoints(path: string, pts: [] Point2f) {
var f = open(path, iomode.cw);
var w = f.writer(iokind.native, locking=false);
