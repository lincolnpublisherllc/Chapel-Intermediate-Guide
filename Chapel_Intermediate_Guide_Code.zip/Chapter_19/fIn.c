Chapel’s IO module gives you files and channels. Think “open a file,” then “get a reader or writer channel,” then “read or write a record at a time.” Channels are buffered by default, which keeps I/O fast.
use IO;

proc copyFile(src: string, dst: string) {
var fIn  = open(src, iomode.r);
var fOut = open(dst, iomode.cw);        // create or truncate
var r = fIn.reader();
var w = fOut.writer();

var line: string;
while r.readln(line) do w.writeln(line);

r.close(); w.close();
fIn.close(); fOut.close();
}
