module csv {
use IO;
use model;

iter lines(path: string, bufSize: int = 1<<20) {
var f = open(path, iomode.r);
var r = f.reader(iokind.native, locking=false, hints=IOHINT_SEQUENTIAL, bufSize=bufSize);
var line: string;
while r.readln(line) do yield line;
r.close(); f.close();
}
