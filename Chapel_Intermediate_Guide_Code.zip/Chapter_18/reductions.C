const N = 1_000_000;
const D = 1..N;                 // dense range
var A: [D] int;                 // fast, cache-friendly
