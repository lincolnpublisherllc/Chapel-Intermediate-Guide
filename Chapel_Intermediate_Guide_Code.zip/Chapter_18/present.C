var K: domain(int);             // sparse set of ints
var H: [K] real;                // sparse map
