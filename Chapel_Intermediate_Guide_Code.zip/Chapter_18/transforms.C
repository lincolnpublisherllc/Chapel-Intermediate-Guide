const VD = 1..N;
const MD = {VD, VD};
var M: [MD] bool;

proc addEdgeDense(u: int, v: int, undirected = true) {
M[u, v] = true; if undirected then M[v, u] = true;
}
