forall k in HD do hist[k] = + reduce [c in 1..chunks] locals[c][k];
return hist;
}
