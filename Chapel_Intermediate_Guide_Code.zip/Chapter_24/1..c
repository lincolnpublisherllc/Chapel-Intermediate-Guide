var step = 1; var cur = W;
while step < cur {
coforall i in 1..cur by 2*step {
const j = i + step;
if j <= cur then metrics.merge(locals[i], locals[j]);
}
step *= 2;
}
const A = locals[1];

report.printText(A, cfg.top);
if cfg.out != "" then {
report.writeCSV(A, cfg.out);
writeln("\nWrote CSV: ", cfg.out);
}
}
}
