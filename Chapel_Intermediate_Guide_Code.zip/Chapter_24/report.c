Dedupe is O(n) extra hashing per line; if your logs don’t duplicate across files, disable it.
