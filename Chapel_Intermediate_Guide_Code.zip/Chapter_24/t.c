"  p99=", percentile(t, 99));
}
}

proc writeCSV(A: Accum, path: string) {
use IO;
var f = open(path, iomode.cw);
var w = f.writer();
w.writeln("endpoint,count,errors,mean_ms,p50,p95,p99,min_ms,max_ms");
for ep in A.Keys {
const t = A.Map[ep];
