module app {
use cfg, fs, csv, hash, dedupe, metrics, report;

proc main() {
if cfg.help || cfg.inputs == "" {
cfg.usage(); return;
}

const files = fs.expandAll(cfg.inputs);
if files.domain.size == 0 { writeln("no inputs"); return; }

const W = max(1, cfg.workers);
const FD = files.domain;
