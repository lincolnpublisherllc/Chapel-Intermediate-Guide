extern proc system(cmd: c_string): int;

proc main() {
const exe = "./bin/app";
const got = "test/golden/tiny.got";
const cmd = (exe + " --inputs=test/golden/tiny-a.csv,test/golden/tiny-b.csv --workers=2 --top=3 > " + got):c_string;
assert(system(cmd) == 0);

use IO;
proc readAll(p: string): string {
var f = open(p, iomode.r); var r = f.reader();
var s = ""; var line: string; var first = true;
while r.readln(line) do { if first then { s=line; first=false; } else s += "\n"+line; }
r.close(); f.close(); return s;
}

const exp = readAll("test/golden/tiny.out.golden");
const gotS = readAll(got);
assert(exp == gotS, "golden mismatch");
writeln("cli tiny ok");
}
