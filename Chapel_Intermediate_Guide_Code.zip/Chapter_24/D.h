proc expandOne(pattern: string): [] string {
if pattern.find("*") < 0 then return [pattern];
const dir  = dirname(pattern);
const base = basename(pattern);
const star = base.find("*");
const pre  = base.substring(1, star);
const suf  = base.substring(star+2, base.length);
var D = 1..0; var out: [D] string;
for e in listdir(dir) {
if e.startsWith(pre) && e.endsWith(suf) {
D = 1..(D.size+1); out[D.high] = joinPath(dir, e);
}
}
return out;
}

proc expandAll(paths: string): [] string {
var files: [1..0] string; var D = 1..0;
for token in splitCSV(paths) {
for f in expandOne(token) {
D = 1..(D.size+1); files[D.high] = f;
}
}
return files;
}
}
