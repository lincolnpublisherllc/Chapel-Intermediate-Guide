proc fillStdNormal(ref rng, ref z: [] real) {
const D = z.domain;
var i = D.low;
while i <= D.high {
const u1 = rng.getNext(); const u2 = rng.getNext();
const r  = sqrt(-2.0*log(max(u1, 1e-16)));
const th = 2.0*PI*u2;
z[i] = r*cos(th);
if i+1 <= D.high then z[i+1] = r*sin(th);
i += 2;
}
}
