var lo: real; var hi: real; param B: int = 10000;
var H: [0..B-1] int;
}

proc initStats(lo: real, hi: real, B: int = 10000) {
var s: Stats; s.lo = lo; s.hi = hi; s.B = B; return s;
}

inline proc bump(ref S: Stats, x: real) {
S.count += 1; S.sum += x; S.sumsq += x*x;
const r = (x - S.lo) / (S.hi - S.lo);
var b = (r * S.B:real):int;
if b < 0 then b = 0; if b >= S.B then b = S.B-1;
S.H[b] += 1;
}

inline proc combine(ref A: Stats, const ref B: Stats) {
A.count += B.count; A.sum += B.sum; A.sumsq += B.sumsq;
forall i in A.H.domain do A.H[i] += B.H[i];
}

proc mean(S: Stats): real   return if S.count>0 then S.sum/S.count:real else 0.0;
proc stdev(S: Stats): real  {
if S.count<=1 then return 0.0;
const m = mean(S);
return sqrt(max(0.0, S.sumsq/S.count:real - m*m));
}

proc quantile(S: Stats, p: real): real {
if S.count == 0 then return 0.0;
const target = max(1, (p * S.count:real / 100.0):int);
var acc = 0;
for b in S.H.domain {
acc += S.H[b];
if acc >= target {
const f = S.lo + (S.hi - S.lo) * (b+0.5):real / S.B:real;
return f;
}
}
return S.hi;
}

proc cvar(S: Stats, p: real): real {
const VaR = quantile(S, p);
