proc report(S: Stats, label: string) {
writeln("\nMonte Carlo (", label, ")");
