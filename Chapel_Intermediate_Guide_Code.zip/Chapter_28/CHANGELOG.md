Sketches for quantiles and heavy hitters; approximate data structures.
