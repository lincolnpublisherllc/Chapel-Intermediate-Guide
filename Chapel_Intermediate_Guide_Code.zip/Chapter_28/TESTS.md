Use coforall workers and per-task locals; combine at the end.
