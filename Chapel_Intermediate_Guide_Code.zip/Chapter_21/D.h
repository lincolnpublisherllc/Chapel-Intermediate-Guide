const N = min(K, Keys.size);
const D = 1..N;
var top: [D] (string, Totals) = [("", new Totals())];

for k in Keys {
const t = Map[k];
for i in D {
if t.sum > top[i][2].sum {
for j in D.high..(i+1) by -1 do top[j] = top[j-1];
top[i] = (k, t); break;
}
}
}
