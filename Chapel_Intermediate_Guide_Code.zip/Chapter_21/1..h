locals[p][A[i] & 255] += 1;
}
var hist: [B] int;
forall b in B do hist[b] = + reduce [p in 1..here.maxTaskPar] locals[p][b];
