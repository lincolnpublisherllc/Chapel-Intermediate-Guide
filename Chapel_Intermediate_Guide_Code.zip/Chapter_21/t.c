for (rank, entry) in zip(D, top) {
const k = entry[1]; const t = entry[2];
writeln(rank, ",", k, ",", t.count, ",", t.sum);
}
}
