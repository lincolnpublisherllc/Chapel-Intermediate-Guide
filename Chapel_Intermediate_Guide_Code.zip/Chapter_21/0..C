We’ll use two ring buffers: bufL for lines, bufR for rows.
param CAP = 4096;

var bufL: [0..CAP-1] sync string;
var bufR: [0..CAP-1] sync Row;

var headL, tailL, headR, tailR: atomic int;

inline proc pushLine(s: string) {
const t = tailL.fetchAdd(1) % CAP;
bufL[t] = s;                  // blocks if full
}

inline proc popLine(): string {
const h = headL.fetchAdd(1) % CAP;
return bufL[h];               // blocks if empty
}

inline proc pushRow(r: Row) {
const t = tailR.fetchAdd(1) % CAP;
bufR[t] = r;                  // blocks if full
}

inline proc popRow(): Row {
const h = headR.fetchAdd(1) % CAP;
return bufR[h];               // blocks if empty
}
