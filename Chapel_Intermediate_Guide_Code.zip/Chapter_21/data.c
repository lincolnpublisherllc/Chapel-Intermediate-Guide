config const input: string = "examples/data.csv";
config const K: int = 10;
config const W: int = max(1, here.maxTaskPar);  // number of transformers

proc main() {
cobegin {
