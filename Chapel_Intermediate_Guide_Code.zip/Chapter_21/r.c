use IO;

proc ingest(path: string, workers: int) {
var f = open(path, iomode.r);
var r = f.reader(iokind.native, locking=false, hints=IOHINT_SEQUENTIAL, bufSize=1<<20);
var line: string;
while r.readln(line) do pushLine(line);
r.close(); f.close();
