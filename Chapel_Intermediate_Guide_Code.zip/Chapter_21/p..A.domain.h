const B = 0..255;
var locals: [1..here.maxTaskPar] [B] int;

coforall p in 1..here.maxTaskPar {
