const parts = here.maxTaskPar;
var partial: [1..parts] int;

coforall p in 1..parts {
var local = 0;
for i in p..D.high by parts do if A[i] > 0 then local += 1;
partial[p] = local;
}

const positives = + reduce partial;
