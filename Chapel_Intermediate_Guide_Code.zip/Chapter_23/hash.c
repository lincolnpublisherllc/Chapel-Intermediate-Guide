require "src/c/hash.c", "src/c/hash.h";
extern proc fnv1a32(data: c_ptr(uint(8)), n: c_size_t): uint(32);
