use IO;

var f = open("out.txt", iomode.cw);
var w = f.writer(); w.writeln("hello"); w.close(); f.close();
