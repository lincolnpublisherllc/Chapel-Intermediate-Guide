Use require "…c" in the module that declares the extern procs.
