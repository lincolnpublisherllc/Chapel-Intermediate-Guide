uint32_t fnv1a32(const uint8_t* data, size_t n);
