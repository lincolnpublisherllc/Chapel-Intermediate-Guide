require "src/c/fnv.c", "src/c/fnv.h";
