extern proc parse_double(s: c_string, out: c_ptr(real(64))): c_int;

proc toReal(s: string): (bool, real) {
var x: real(64);
const rc = parse_double(s.c_str(), c_ptrTo(x));
return (rc == 0, x);
}
