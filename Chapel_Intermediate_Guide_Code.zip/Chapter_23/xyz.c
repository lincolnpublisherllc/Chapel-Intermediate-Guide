Add require "src/c/xyz.c" in a module that everyone imports (commonly the module that also declares the extern procs).
