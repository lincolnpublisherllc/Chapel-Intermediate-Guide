use FileSystem, Path;

if exists("out.txt") then writeln("found");
writeln(joinPath("data", "file.csv"));
