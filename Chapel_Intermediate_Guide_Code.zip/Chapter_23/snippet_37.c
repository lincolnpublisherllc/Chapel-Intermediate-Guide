extern record point_t {
var x: real(64);
var y: real(64);
}
